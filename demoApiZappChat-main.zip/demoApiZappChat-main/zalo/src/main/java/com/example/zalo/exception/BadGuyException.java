package com.example.zalo.exception;

public class BadGuyException extends RuntimeException{
    public BadGuyException(String msg) {
        super(msg);
    }
}
