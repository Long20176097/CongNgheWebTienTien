package com.example.zalo.entity;

public enum MessageStatus {
    RECEIVED, DELIVERED
}
