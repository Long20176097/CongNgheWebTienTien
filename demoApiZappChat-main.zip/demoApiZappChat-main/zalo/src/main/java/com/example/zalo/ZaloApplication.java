package com.example.zalo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZaloApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZaloApplication.class, args);
	}

}
