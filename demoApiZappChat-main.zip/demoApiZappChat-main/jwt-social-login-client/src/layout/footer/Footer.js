import React from 'react';
import './Footer.css'

const Footer = () => {
    return (
        <footer className="footer mt-5">
        </footer>
    );
};

export default Footer;